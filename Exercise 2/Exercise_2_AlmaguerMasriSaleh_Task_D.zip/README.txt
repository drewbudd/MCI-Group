NOTE TO THE GRADER:

If you would like to test the whole program, but do not want to go through ever single test 20-25 times, change the values of the two variables on lines 153-154 of index.html.
